<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PagesController extends Controller
{
    public function index()
    {
        $mata_kuliah = DB::table('mata_kuliah')->pluck('mata_kuliah');
        $jumlah_mhs = DB::table('mata_kuliah')->pluck('jml_mahasiswa');

        return view('index', compact('mata_kuliah', 'jumlah_mhs'));
    }
}
