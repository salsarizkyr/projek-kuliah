<?php

namespace App\Http\Controllers;

use App\Models\MataKuliah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MataKuliahController extends Controller
{
    public function index()
    {
        $mata_kuliah = MataKuliah::latest()->paginate(10);

        return view('mata_kuliah.index', compact('mata_kuliah'));
    }

    public function create()
    {
        return view('mata_kuliah.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'kd_mk' => 'unique:mata_kuliah,kd_mk',
            'jam_mulai' => 'date_format:H:i',
            'jam_selesai' => 'date_format:H:i'
        ], [
            'kd_mk.unique' => 'Kode MK sudah ada',
            'jam_mulai.date_format' => 'Format jam mulai salah',
            'jam_selesai.date_format' => 'Format jam selesai salah'
        ]);

        MataKuliah::create($request->except('_token'));

        return redirect()->route('mata-kuliah.index')->with('success', 'Data berhasil ditambah');
    }

    public function edit(MataKuliah $mata_kuliah)
    {
        return view('mata_kuliah.edit', compact('mata_kuliah'));
    }

    public function update(Request $request, MataKuliah $mata_kuliah)
    {
        $this->validate($request, [
            'jam_mulai' => 'date_format:H:i',
            'jam_selesai' => 'date_format:H:i'
        ], [
            'jam_mulai.date_format' => 'Format jam mulai salah',
            'jam_selesai.date_format' => 'Format jam selesai salah'
        ]);
        
        if($mata_kuliah->kd_mk != $request->kd_mk) {
            $check = DB::table('mata_kuliah')->where('kd_mk', '=', $request->kd_mk)->count();

            if($check) {
                return redirect()->back()->with('error', 'Kode MK sudah digunakan');
            }
        }

        $mata_kuliah->update($request->except('_token', '_method'));

        return redirect()->route('mata-kuliah.index')->with('success', 'Data berhasil diubah');
    }

    public function destroy(MataKuliah $mata_kuliah)
    {
        $mata_kuliah->delete();

        return redirect()->route('mata-kuliah.index')->with('success', 'Data berhasil dihapus');        
    }
}
