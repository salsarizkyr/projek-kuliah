<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Session;

class BeritaController extends Controller
{
    public function show()
    {
        $beritas = DB::table('berita')->orderby('id', 'desc')->get();
        return view('show', ['beritas'=>$beritas]);
    }
 
    public function add()
    {
        return view('add');
    }
 
    public function add_process(Request $berita)
    {
        DB::table('berita')->insert([
            'nama'=>$berita->nama,
            'alamat'=>$berita->alamat,
            'tempat_lahir'=>$berita->tempat_lahir,
            'isi_berita'=>$berita->isi_berita
        ]);
        return redirect()->action('BeritaController@show');
    }
    public function detail($id)
    {
        $berita = DB::table('berita')->where('id', $id)->first();
        return view('detail', ['berita'=>$berita]);
    }
    public function show_by_admin()
    {
        $beritas = DB::table('berita')->orderby('id', 'desc')->get();
        return view('adminshow', ['beritas'=>$beritas]);
    }
    public function edit($id)
    {
        $berita = DB::table('berita')->where('id', $id)->first();
        return view('edit', ['berita'=>$berita]);
    }
    public function edit_process(Request $berita)
    {
        $id = $berita->id;
        $nama = $berita->nama;
        $alamat = $berita->alamat;
        $tempat_lahir = $berita->tempat_lahir;
        $isi_berita = $berita->isi_berita;
        DB::table('berita')->where('id', $id)
                            ->update(['nama' => $nama, 'nama' => $nama]);
        Session::flash('success', 'Berita berhasil diedit');
        return redirect()->action('BeritaController@show_by_admin');
    }

     public function delete($id)
    {
        //menghapus artikel dengan ID sesuai pada URL
        DB::table('berita')->where('id', $id)
                            ->delete();
 
        //membuat pesan yang akan ditampilkan ketika artikel berhasil dihapus
        Session::flash('success', 'Berita berhasil dihapus');
        return redirect()->action('BeritaController@show_by_admin');
    }

}
