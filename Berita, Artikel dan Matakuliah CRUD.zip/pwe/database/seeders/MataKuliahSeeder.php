<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MataKuliahSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('mata_kuliah')->insert([
            [
                'kd_mk' => 'MK0001',
                'hari' => 'Senin',
                'jam_mulai' => '13:00',
                'jam_selesai' => '14:00',
                'mata_kuliah' => 'Database',
                'kelas' => 'TI A',
                'dosen' => 'Diki',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '10',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0002',
                'hari' => 'Selasa',
                'jam_mulai' => '13:00',
                'jam_selesai' => '14:00',
                'mata_kuliah' => 'Pemrograman Website',
                'kelas' => 'TI B',
                'dosen' => 'Diki',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '15',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0003',
                'hari' => 'Rabu',
                'jam_mulai' => '13:45',
                'jam_selesai' => '16:00',
                'mata_kuliah' => 'Algoritma Dasar',
                'kelas' => 'SI B',
                'dosen' => 'Andreas',
                'unit_kelas' => 'Sistem Informasi',
                'jml_mahasiswa' => '20',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0004',
                'hari' => 'Kamis',
                'jam_mulai' => '13:00',
                'jam_selesai' => '14:00',
                'mata_kuliah' => 'Kewarganegaraan',
                'kelas' => 'TI A',
                'dosen' => 'Irma',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '11',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0005',
                'hari' => 'Senin',
                'jam_mulai' => '13:00',
                'jam_selesai' => '14:00',
                'mata_kuliah' => 'Database',
                'kelas' => 'TI C',
                'dosen' => 'Diki',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '10',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0006',
                'hari' => 'Jumat',
                'jam_mulai' => '15:00',
                'jam_selesai' => '16:00',
                'mata_kuliah' => 'Pemrograman Mobile',
                'kelas' => 'SI B',
                'dosen' => 'Jonathan',
                'unit_kelas' => 'Sistem Informasi',
                'jml_mahasiswa' => '23',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0007',
                'hari' => 'Senin',
                'jam_mulai' => '08:00',
                'jam_selesai' => '19:00',
                'mata_kuliah' => 'Database',
                'kelas' => 'TI B',
                'dosen' => 'Diki',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '10',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0008',
                'hari' => 'Selasa',
                'jam_mulai' => '09:00',
                'jam_selesai' => '10:00',
                'mata_kuliah' => 'Database',
                'kelas' => 'TI C',
                'dosen' => 'Diki',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '10',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0009',
                'hari' => 'Jumat',
                'jam_mulai' => '14:00',
                'jam_selesai' => '15:00',
                'mata_kuliah' => 'Kewirausahaan',
                'kelas' => 'SI A',
                'dosen' => 'Indah',
                'unit_kelas' => 'Sistem Informasi',
                'jml_mahasiswa' => '10',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ],
            [
                'kd_mk' => 'MK0010',
                'hari' => 'Kamis',
                'jam_mulai' => '13:40',
                'jam_selesai' => '14:00',
                'mata_kuliah' => 'Database',
                'kelas' => 'TI B',
                'dosen' => 'Diki',
                'unit_kelas' => 'Teknik Informatika',
                'jml_mahasiswa' => '17',
                'created_at' => date('Y-m-d'),
                'updated_at' => date('Y-m-d')
            ]
        ]);
    }
}
