<!-- membuat kerangka dari master.blade.php -->
@extends('master')
 
<!-- membuat komponen title sebagai judul halaman -->
@section('title', 'Menambah Berita')
 
@section('main')
<div class="col-md-8 col-sm-12 bg-white p-4">
    <form method="GET" action="/add_process">
    @csrf
        <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" name="nama" placeholder="Nama">
        </div>
        <div class="form-group">
            <label>Alamat</label>
            <textarea class="form-control" name="alamat" rows="3"></textarea>
        </div>
        <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" class="form-control" name="tempat_lahir" placeholder="Tempat Lahir">
        </div>
        <div class="form-group">
            <label>Isi Berita</label>
            <textarea class="form-control" name="isi_berita" rows="10"></textarea>
        </div>
</div>
@endsection
 
@section('sidebar')
<div class="col-md-3 ml-md-5 col-sm-12 bg-blue p-4" style="height:120px !important">
    <div class="form-group">
        <label>Upload</label>
        <input type="submit" class="form-control btn btn-danger" value="Upload">
    </div>
</div>
</form>
@endsection