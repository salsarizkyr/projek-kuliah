@extends('template.app')

@section('title', 'Login')

@section('content')
    <div class="row justify-content-center">
        <div class="col-lg-5">
            @if(request()->session()->has('error'))
                <div class="alert alert-danger">
                    {{ request()->session()->get('error') }}
                </div>
            @endif
            <div class="card">
                <div class="card-header">
                    <p class="card-title">Login</p>
                </div>
                <div class="card-body">
                    <form action="{{ url('/login') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <input type="email" class="form-control" name="email" placeholder="Email Anda" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" name="password" placeholder="Password Anda" required>
                        </div>
                        <div class="mb-3 d-grid gap-2"">
                            <button type="submit" class="btn btn-primary">LOGIN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
