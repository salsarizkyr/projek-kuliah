@extends('master')
 
@section('title', 'Edit Berita')
 
@section('header')
<center class="mt-4">
    <h2>Edit Berita</h2>
</center>
@endsection
 
@section('main')
<div class="col-md-8 col-sm-12 bg-white p-4">
    <form method="post" action="/edit_process">
    @csrf
	<input type="hidden" value="{{ $berita->id }}" name="id">
        <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" value="{{ $berita->nama }}" name="nama" placeholder="Nama">
        </div>
        <div class="form-group">
            <label>Alamat</label>
            <textarea class="form-control" name="alamat" rows="10">{{ $berita->alamat }}
            </textarea>
        </div>
        <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" class="form-control" value="{{ $berita->tempat_lahir }}" name="tempat_lahir" placeholder="Tempat Lahir">
        </div>
        <div class="form-group">
            <label>Isi Berita</label>
            <textarea class="form-control" name="isi_berita" rows="15">{{ $berita->isi_berita }}
            </textarea>
        </div>
</div>
@endsection
 
<!-- membuat komponen sidebar yang berisi tombol untuk upload artikel -->
@section('sidebar')
<div class="col-md-3 ml-md-5 col-sm-12 bg-white p-4" style="height:120px !important
    <div class="form-group">
        <label>Edit</label>
        <input type="submit" class="form-control btn btn-danger" value="Edit">
    </div>
</div>
</form>
@endsection