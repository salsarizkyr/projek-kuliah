@extends('template.app')

@section('title', 'Mata Kuliah')

@section('content')
    <div class="row">
        <div class="col-lg-12">
            @if(request()->session()->has('success'))
                <div class="alert alert-success" role="alert">
                    {{ request()->session()->get('success') }}
                </div>
            @endif
            <div class="mb-3">
                <a href="{{ route('mata-kuliah.create') }}" class="btn btn-sm btn-primary">Tambah Data</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <p class="card-title">Mata Kuliah</p>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Hari</th>
                                    <th>Jam</th>
                                    <th>Kode MK</th>
                                    <th>Mata Kuliah</th>
                                    <th>Kelas</th>
                                    <th>Dosen</th>
                                    <th>Unit Kelas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($mata_kuliah as $i => $data)
                                    <tr>
                                        <td>{{ $mata_kuliah->firstItem() + $i }}</td>
                                        <td>{{ $data->hari }}</td>
                                        <td>{{ $data->jam_mulai->format('H:i') }} - {{ $data->jam_selesai->format('H:i') }}</td>
                                        <td>{{ $data->kd_mk }}</td>
                                        <td>{{ $data->mata_kuliah }}</td>
                                        <td>{{ $data->kelas }}</td>
                                        <td>{{ $data->dosen }}</td>
                                        <td>{{ $data->unit_kelas }}</td>
                                        <td>
                                            <form action="{{ route('mata-kuliah.destroy', $data->kd_mk) }}" method="POST">
                                                @csrf
                                                <input type="hidden" name="_method" value="DELETE">
                                                <a href="{{ route('mata-kuliah.edit', $data->kd_mk) }}" class="btn btn-sm btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-sm btn-info">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{ $mata_kuliah->onEachSide(5)->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection