@extends('template.app')

@section('title', 'Mata Kuliah')

@section('content')
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-header">
                    <p class="card-title">Tambah Mata Kuliah</p>
                </div>
                <div class="card-body">
                    <form action="{{ route('mata-kuliah.store') }}" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-lg-4">
                                <label for="kd_mk">Kode MK <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('kd_mk') is-invalid @enderror" name="kd_mk" id="kd_mk" value="{{ old('kd_mk') }}" required>
                                @error('kd_mk')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-lg-8">
                                <label for="mata_kuliah">Mata Kuliah <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="mata_kuliah" id="mata_kuliah" value="{{ old('mata_kuliah') }}" required>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-lg-2">
                                <label for="hari">Hari <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="hari" id="hari" value="{{ old('hari') }}" required>
                            </div>
                            <div class="col-lg-3">
                                <label for="jam_mulai">Jam Mulai <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('jam_mulai') is-invalid @enderror" name="jam_mulai" id="jam_mulai" placeholder="Misal: 13:00" value="{{ old('jam_mulai') }}" required>
                                @error('jam_mulai')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-lg-3">
                                <label for="jam_selesai">Jam Selesai <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('jam_selesai') is-invalid @enderror" name="jam_selesai" id="jam_selesai" placeholder="Misal: 14:00" value="{{ old('jam_selesai') }}" required>
                                @error('jam_selesai')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-lg-4">
                                <label for="dosen">Nama Dosen <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="dosen" id="dosen" value="{{ old('dosen') }}" required>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-lg-3">
                                <label for="kelas">Kelas <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="kelas" id="kelas" value="{{ old('kelas') }}" required>
                            </div>
                            <div class="col-lg-6">
                                <label for="unit_kelas">Unit Kelas <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="unit_kelas" id="unit_kelas" value="{{ old('unit_kelas') }}" required>
                            </div>
                            <div class="col-lg-3">
                                <label for="jml_mahasiswa">Jumlah Mahasiswa <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="jml_mahasiswa" id="jml_mahasiswa" value="{{ old('jml_mahasiswa') }}" required>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="reset" class="btn btn-sm btn-secondary">Reset</button>
                            <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection