<!-- menggunakan kerangka dari master.blade.php -->
@extends('master')
 
@section('header')
<h2><center>Halaman Berita</center></h2>
@if($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
          <strong>{{ $message }}</strong>
    </div>
    @endif
 
@endsection
 
@section('title', 'Halaman Khusus Admin')
 
@section('main')
    <div class="col-md-12 bg-white p-4">
        <a href="/add"><button class="btn btn-danger mb-3">Tambah Berita</button></a>
        <table class="table table-danger table-responsive table-bordered table-hover table-stripped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Tempat Lahir</th>
                    <th>Isi Berita</th>
                    <th width="15%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($beritas as $i => $berita)
                    <tr>
                        <td>{{ ++$i }}</td>
                        <td>{{ $berita->nama }}</td>
                        <td>{{ $berita->alamat }}</td>
                        <td>{{ $berita->tempat_lahir }}</td>
                        <td>{{ $berita->isi_berita }}</td>
                        <td>
                            <a href="/edit/{{ $berita->id }}"><button class="btn btn-dark">Edit</button></a>
                            <a href="/delete/{{ $berita->id }}"><button class="btn btn-danger">Hapus</button></a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection