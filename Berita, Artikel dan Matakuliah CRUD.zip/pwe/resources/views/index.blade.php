@extends('template.app')

@section('title', 'Home')

@section('content')
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <p class="card-title"><font color="#0E6893"><b><center>Grafik Mata Kuliah</center></b></font></p>
                </div>
                <div class="card-body">
                    <canvas id="myChart"></canvas>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: @json($mata_kuliah),
                datasets: [{
                    label: 'Grafik Mata Kuliah',
                    data: @json($jumlah_mhs),
                    backgroundColor: 'rgba(106, 182, 233, 1)',
                    borderColor: 'rgba(90, 170, 225, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
@endpush
