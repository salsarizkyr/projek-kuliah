<!-- menggunakan kerangka dari halaman master.blade.php --> 
@extends('master')
 
<!-- membuat komponen title sebagai judul halaman -->
@section('title', 'Blog Niaga')
 
<!-- membuat header dan tombol tambah berita di atas -->
@section('header')
    <center>
        <h2>Salsa News</h2><br/>
        <a href="/add"><button class="btn btn-dark">Tambah Berita</button></a>
    </center>
@endsection
 
@section('main')
    @foreach ($beritas as $berita)
    <div class="col-md-4 col-sm-12 mt-4">
        <div class="card">
        <img src="http://localhost:8000/img/vaksin.jpg" class="card-img-top" alt="gambar" >       
            <div class="card-body">
                <h5 class="card-title">{{ $berita->nama }}</h5>
                <h5 class="card-title">{{ $berita->alamat }}</h5>
                <h5 class="card-title">{{ $berita->tempat_lahir }}</h5>
                <a href="/detail/{{ $berita->id }}" class="btn btn-danger">Baca Berita</a>
            </div>
        </div>
    </div>
   @endforeach
@endsection