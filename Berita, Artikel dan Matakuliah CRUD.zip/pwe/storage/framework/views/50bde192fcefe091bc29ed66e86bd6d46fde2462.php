<?php $__env->startSection('title', 'Mata Kuliah'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(request()->session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(request()->session()->get('success')); ?>

                </div>
            <?php endif; ?>
            <div class="mb-3">
                <a href="<?php echo e(route('mata-kuliah.create')); ?>" class="btn btn-sm btn-primary">Tambah Data</a>
            </div>
            <div class="card">
                <div class="card-header">
                    <p class="card-title">Mata Kuliah</p>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Hari</th>
                                    <th>Jam</th>
                                    <th>Kode MK</th>
                                    <th>Mata Kuliah</th>
                                    <th>Kelas</th>
                                    <th>Dosen</th>
                                    <th>Unit Kelas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $mata_kuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($mata_kuliah->firstItem() + $i); ?></td>
                                        <td><?php echo e($data->hari); ?></td>
                                        <td><?php echo e($data->jam_mulai->format('H:i')); ?> - <?php echo e($data->jam_selesai->format('H:i')); ?></td>
                                        <td><?php echo e($data->kd_mk); ?></td>
                                        <td><?php echo e($data->mata_kuliah); ?></td>
                                        <td><?php echo e($data->kelas); ?></td>
                                        <td><?php echo e($data->dosen); ?></td>
                                        <td><?php echo e($data->unit_kelas); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('mata-kuliah.destroy', $data->kd_mk)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <a href="<?php echo e(route('mata-kuliah.edit', $data->kd_mk)); ?>" class="btn btn-sm btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-sm btn-info">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($mata_kuliah->onEachSide(5)->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pwe\resources\views/mata_kuliah/index.blade.php ENDPATH**/ ?>