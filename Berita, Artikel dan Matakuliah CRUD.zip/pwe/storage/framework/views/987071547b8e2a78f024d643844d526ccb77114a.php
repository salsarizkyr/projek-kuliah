<?php $__env->startSection('title', 'Mata Kuliah'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-header">
                    <p class="card-title">Tambah Mata Kuliah</p>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('mata-kuliah.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-4">
                                <label for="kd_mk">Kode MK <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['kd_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kd_mk" id="kd_mk" value="<?php echo e(old('kd_mk')); ?>" required>
                                <?php $__errorArgs = ['kd_mk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-8">
                                <label for="mata_kuliah">Mata Kuliah <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="mata_kuliah" id="mata_kuliah" value="<?php echo e(old('mata_kuliah')); ?>" required>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-lg-2">
                                <label for="hari">Hari <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="hari" id="hari" value="<?php echo e(old('hari')); ?>" required>
                            </div>
                            <div class="col-lg-3">
                                <label for="jam_mulai">Jam Mulai <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['jam_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jam_mulai" id="jam_mulai" placeholder="Misal: 13:00" value="<?php echo e(old('jam_mulai')); ?>" required>
                                <?php $__errorArgs = ['jam_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-3">
                                <label for="jam_selesai">Jam Selesai <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['jam_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jam_selesai" id="jam_selesai" placeholder="Misal: 14:00" value="<?php echo e(old('jam_selesai')); ?>" required>
                                <?php $__errorArgs = ['jam_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-4">
                                <label for="dosen">Nama Dosen <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="dosen" id="dosen" value="<?php echo e(old('dosen')); ?>" required>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-lg-3">
                                <label for="kelas">Kelas <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="kelas" id="kelas" value="<?php echo e(old('kelas')); ?>" required>
                            </div>
                            <div class="col-lg-6">
                                <label for="unit_kelas">Unit Kelas <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="unit_kelas" id="unit_kelas" value="<?php echo e(old('unit_kelas')); ?>" required>
                            </div>
                            <div class="col-lg-3">
                                <label for="jml_mahasiswa">Jumlah Mahasiswa <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" name="jml_mahasiswa" id="jml_mahasiswa" value="<?php echo e(old('jml_mahasiswa')); ?>" required>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button type="reset" class="btn btn-sm btn-secondary">Reset</button>
                            <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pwe\resources\views/mata_kuliah/create.blade.php ENDPATH**/ ?>