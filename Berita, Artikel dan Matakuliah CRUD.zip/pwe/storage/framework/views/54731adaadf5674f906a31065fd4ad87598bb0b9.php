<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-5">
            <?php if(request()->session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(request()->session()->get('error')); ?>

                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <p class="card-title">Login</p>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(url('/login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <input type="email" class="form-control" name="email" placeholder="Email Anda" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" class="form-control" name="password" placeholder="Password Anda" required>
                        </div>
                        <div class="mb-3 d-grid gap-2"">
                            <button type="submit" class="btn btn-primary">LOGIN</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pwe\resources\views/auth/login.blade.php ENDPATH**/ ?>