<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\MataKuliahController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => 'auth'], function() {
    Route::get('/', [PagesController::class, 'index']);
    Route::resource('mata-kuliah', MataKuliahController::class)->except('show');
    Route::get('/logout', [AuthController::class, 'doLogout']);
});

Route::group(['middleware' => 'guest'], function() {
    Route::get('/login', [AuthController::class, 'getLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'doLogin']);
});
//Quiz 14
Route::get('/test', function() {
    return view('master');
});
Route::get('/add', function () {
   return view('add');
});
Route::get('/', 'ArtikelController@show');
Route::get('/add_process', 'ArtikelController@add_process');
Route::get('/detail/{id}', 'ArtikelController@detail');
Route::get('/admin', 'ArtikelController@show_by_admin');
Route::get('/edit/{id}', 'ArtikelController@edit');
Route::post('/edit_process', 'ArtikelController@edit_process');
Route::get('/delete/{id}', 'ArtikelController@delete');
// Quiz 15
Route::get('/test', function() {
    return view('master');
});
Route::get('/add', function () {
   return view('add');
});
Route::get('/', 'BeritaController@show');
Route::get('/add_process', 'BeritaController@add_process');
Route::get('/detail/{id}', 'BeritaController@detail');
Route::get('/admin', 'BeritaController@show_by_admin');
Route::get('/edit/{id}', 'BeritaController@edit');
Route::post('/edit_process', 'BeritaController@edit_process');
Route::get('/delete/{id}', 'BeritaController@delete');
